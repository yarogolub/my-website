# About me

I’m Yaro. 

I’m finishing studying Electrical Engineering at the University of Calgary, graduating in June 2025.

I’m currently at JPAK Engineering. 

My interests are in the fields of Power Systems, RF Design, Embedded system design and FPGAs.

![IMG_0750.JPG](IMG_0750.jpg)

My values:

Hard labour

Thinking BIG

Ambition

Agency

Self-reflection

Reach out to me if you want to get in touch!