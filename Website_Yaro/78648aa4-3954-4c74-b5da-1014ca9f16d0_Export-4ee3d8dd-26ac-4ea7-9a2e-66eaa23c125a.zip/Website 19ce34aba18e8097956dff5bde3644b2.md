# Website

[About me](https://www.notion.so/About-me-19ce34aba18e80cdbb35c7f239a627d6?pvs=21)

[Projects](https://www.notion.so/Projects-19de34aba18e80b1b977de8071fa6435?pvs=21)

[Blog](https://www.notion.so/Blog-19de34aba18e80199a56e000f8e9a35a?pvs=21)